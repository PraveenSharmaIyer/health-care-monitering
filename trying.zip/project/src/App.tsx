import React, { useState } from 'react';
import { Activity, Heart, Brain, Stethoscope, Weight, Battery, Trophy } from 'lucide-react';

function HealthCard({ icon: Icon, title, value, unit, color }: { 
  icon: React.ElementType, 
  title: string, 
  value: number, 
  unit: string,
  color: string 
}) {
  return (
    <div className="glass-card p-6 health-stat group">
      <div className={`flex items-center gap-3 text-${color}`}>
        <Icon className="w-6 h-6 group-hover:animate-pulse" />
        <h3 className="text-lg font-semibold">{title}</h3>
      </div>
      <p className="mt-3 text-2xl font-bold neon-text">
        {value}
        <span className="text-sm ml-1 opacity-70">{unit}</span>
      </p>
    </div>
  );
}

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-red-950 to-black p-8">
      <div className="max-w-7xl mx-auto">
        <header className="glass-card p-6 mb-8">
          <h1 className="text-4xl font-bold neon-text mb-2">HealthSync Pro</h1>
          <p className="text-red-400 opacity-80">Your Health, Your Control</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <HealthCard
            icon={Heart}
            title="Heart Rate"
            value={75}
            unit="bpm"
            color="red-500"
          />
          <HealthCard
            icon={Activity}
            title="Daily Steps"
            value={8432}
            unit="steps"
            color="blue-500"
          />
          <HealthCard
            icon={Brain}
            title="Sleep Quality"
            value={85}
            unit="%"
            color="purple-500"
          />
          <HealthCard
            icon={Stethoscope}
            title="Oxygen Level"
            value={98}
            unit="%"
            color="green-500"
          />
          <HealthCard
            icon={Weight}
            title="Weight"
            value={68}
            unit="kg"
            color="yellow-500"
          />
          <HealthCard
            icon={Battery}
            title="Energy Level"
            value={92}
            unit="%"
            color="emerald-500"
          />
        </div>

        <div className="glass-card mt-8 p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold neon-text">Daily Progress</h2>
            <Trophy className="w-6 h-6 text-yellow-500 animate-pulse" />
          </div>
          <div className="mt-4 h-4 glass-card overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-red-500 to-red-700 w-3/4 rounded-full 
                         transition-all duration-1000 ease-in-out hover:from-red-600 hover:to-red-800"
            />
          </div>
          <p className="mt-2 text-red-400 text-sm">75% of daily goals completed</p>
        </div>
      </div>
    </div>
  );
}

export default App;